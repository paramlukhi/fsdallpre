const express = require("express");
const session = require("express-session");
const path = require("path");

const app = express();
const PORT = 3000;

// Static Credentials
const USER_CREDENTIALS = {
    username: "admin",
    password: "password123"
};

// 1. Parse incoming urlencoded form data
app.use(express.urlencoded({ extended: true }));

// 2. Configure session middleware
app.use(
    session({
        secret: "super-secret-key-change-this-in-production",
        resave: false,
        saveUninitialized: false,
        cookie: {
            maxAge: 1000 * 60 * 30, // Session expires after 30 minutes
            httpOnly: true
        }
    })
);

// 3. Serve static CSS and asset files
app.use(express.static(path.join(__dirname, "public")));

// Custom Authentication Middleware
function checkAuth(req, res, next) {
    if (req.session && req.session.user) {
        return next();
    }
    res.redirect("/login");
}

// Redirect root to dashboard (if authenticated) or login
app.get("/", (req, res) => {
    if (req.session.user) {
        res.redirect("/dashboard");
    } else {
        res.redirect("/login");
    }
});

// GET /login - Render login form
app.get("/login", (req, res) => {
    if (req.session.user) {
        return res.redirect("/dashboard");
    }
    res.sendFile(path.join(__dirname, "views", "login.html"));
});

// POST /login - Handle form submission
app.post("/login", (req, res) => {
    const { username, password } = req.body;

    if (
        username === USER_CREDENTIALS.username &&
        password === USER_CREDENTIALS.password
    ) {
        // Save user data into session
        req.session.user = {
            username: username,
            loggedInAt: new Date().toLocaleTimeString()
        };
        return res.redirect("/dashboard");
    }

    // Redirect back to login with query param on error
    res.redirect("/login?error=invalid");
});

// GET /logout - Destroy session
app.get("/logout", (req, res) => {
    req.session.destroy((err) => {
        if (err) console.error("Session destroy error:", err);
        res.clearCookie("connect.sid");
        res.redirect("/login");
    });
});

// Protected Route 1: Dashboard
app.get("/dashboard", checkAuth, (req, res) => {
    res.sendFile(path.join(__dirname, "views", "dashboard.html"));
});

// Protected Route 2: Profile
app.get("/profile", checkAuth, (req, res) => {
    res.sendFile(path.join(__dirname, "views", "profile.html"));
});

// Protected API Endpoint to get active session details
app.get("/api/user-info", checkAuth, (req, res) => {
    res.json({
        username: req.session.user.username,
        loggedInAt: req.session.user.loggedInAt
    });
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
